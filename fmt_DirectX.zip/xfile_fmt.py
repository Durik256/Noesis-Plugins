#by Durik256
from inc_noesis import *
import xfile_parser

def registerNoesisTypes():
    handle = noesis.register("DirectX", ".x")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    return 1 if data[:4] == b'xof ' else 0

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    
    global bones, meshes, materials, anims, bone_map
    bones, meshes, materials, anims, bone_map = [], [], [], [], {}
    
    parser = xfile_parser.XFileParser(data)
    scene = parser.getImportedData()
    
    for x in scene.globalMeshes:
        meshes.append(x)
        
    for x in scene.globalMaterials:
        convert_material(x)
    
    convert_node(scene.rootNode)
    
    if bones:
        bones = rapi.multiplyBones(bones)

    for i,x in enumerate(meshes):
        convert_mesh(x, i)
    
    for x in scene.anims:
        convert_anim(x)
    
    try: 
        mdl = rapi.rpgConstructModel()
    except: 
        mdl = NoeModel()

    mdl.setAnims(anims)
    mdl.setBones(bones)
    mdl.setModelMaterials(NoeModelMaterials([], materials))
    mdlList.append(mdl)
    return 1

def convert_node(node):
    if not node:
        return
    
    matrix  = NoeMat43()
    if node.trafoMatrix:
        matrix = NoeMat44.fromBytes(noePack('16f', *node.trafoMatrix)).toMat43()
    
    index = len(bones)
    if getBoneIndex(node.name) != -1:
        node.name = "{0}_{1}".format(node.name, index)
    
    bones.append(NoeBone(index, node.name, matrix, node.parent.name if node.parent else None))
    bone_map[node.name] = index
    
    for mesh in node.meshes:
        mesh.nodeIndex = index
        meshes.append(mesh)

    for child in node.children:
        convert_node(child)
    
    return 1
        
def convert_mesh(mesh, i):
    if not mesh.positions:
        return

    rapi.rpgSetName("name_{0}".format(i))
    vnum = len(mesh.positions)
        
    for x in mesh.materials:
        convert_material(x)
    
    newVert = [NoeVec3()]*vnum
    vbuf = bytearray(vnum * 12)
    
    rapi.rpgSetTransform(None)
    if bones and mesh.bones:
        weights = [[[], []] for _ in range(vnum)]
        maxW = 1
        
        for bone in mesh.bones:
            idBone = getBoneIndex(bone.name)
            mat_ofs = NoeMat44.fromBytes(noePack('16f', *bone.offsetMatrix)).toMat43()
            bone_matrix = mat_ofs * bones[idBone].getMatrix()
            
            for x in bone.weights:
                vertex_pos = NoeVec3(mesh.positions[x.vertex])
                newVert[x.vertex] += (bone_matrix * x.weight).transformPoint(vertex_pos)
                weights[x.vertex][0].append(idBone)
                weights[x.vertex][1].append(x.weight)
                maxW = max(maxW, len(weights[x.vertex][0]))
            
            
        wbuf = bytearray(vnum * maxW * 6)
        i_str = '{0}H'.format(maxW)
        w_str = '{0}f'.format(maxW)
        
        for j,w in enumerate(weights):
            idx_count = len(w[0])
            indices = w[0] + [0] * (maxW - idx_count)
            weights_vals = w[1] + [0] * (maxW - idx_count)
            
            struct.pack_into(i_str, wbuf, (j * maxW * 6), *indices)
            struct.pack_into(w_str, wbuf, (j * maxW * 6) + maxW * 2, *weights_vals)
        
        rapi.rpgBindBoneIndexBuffer(wbuf, noesis.RPGEODATA_USHORT, maxW * 6, maxW)
        rapi.rpgBindBoneWeightBufferOfs(wbuf, noesis.RPGEODATA_FLOAT, maxW * 6, maxW * 2, maxW)
    
        for j,vert in enumerate(newVert):
            struct.pack_into('3f', vbuf, j * 12, *vert.getStorage())
        
    else:
        if mesh.nodeIndex != -1:
            if 0 <= mesh.nodeIndex < len(bones):
                rapi.rpgSetTransform(bones[mesh.nodeIndex].getMatrix())

                rapi.rpgBindBoneIndexBuffer(struct.pack('H', mesh.nodeIndex)*vnum, noesis.RPGEODATA_USHORT, 2, 1)
                rapi.rpgBindBoneWeightBuffer(b'\xFF'*vnum, noesis.RPGEODATA_UBYTE, 1, 1)
        
        for j,vert in enumerate(mesh.positions):
            struct.pack_into('3f', vbuf, j * 12, *vert)

    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
    
    
    if mesh.normals and mesh.normalFaces and len(mesh.normalFaces) == len(mesh.posFaces):
        nbuf = bytearray(12 * vnum)
        normal_map = {}
        for face, nface in zip(mesh.posFaces, mesh.normalFaces):
            for v_idx, n_idx in zip(face.indices, nface.indices):
                normal_map[v_idx] = mesh.normals[n_idx]
        default_normal = (0.0, 0.0, 1.0)
        for j in range(vnum):
            normal = normal_map.get(j, default_normal)
            struct.pack_into('3f', nbuf, j * 12, *normal)
        rapi.rpgBindNormalBuffer(nbuf, noesis.RPGEODATA_FLOAT, 12)
    
    
    if mesh.texCoords and len(mesh.texCoords) == vnum:
        uvbuf = bytearray(vnum * 8)
        for j,uv in enumerate(mesh.texCoords):
            struct.pack_into('2f', uvbuf, j * 8, *uv)

        rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 8)

    
    if mesh.colors and len(mesh.colors) > 0 and len(mesh.colors[0]) == vnum:
        cbuf = bytearray(vnum * 16)
        for j,c in enumerate(mesh.colors[0]):
            struct.pack_into('4f', cbuf, j * 16, *c)
        
        rapi.rpgBindColorBuffer(cbuf, noesis.RPGEODATA_FLOAT, 16, 4)
    
    
    if mesh.numMaterials:
        mat_indx = {x: bytearray() for x in range(mesh.numMaterials)}
        
        face_materials = mesh.faceMaterials
        pos_faces = mesh.posFaces
        
        for n in range(len(face_materials)):
            face = pos_faces[n].indices
            material_idx = face_materials[n]
            
            if len(face) == 3:
                mat_indx[material_idx].extend(noePack('3H', *face))
            else:
                for f in triangulate_polygon(face):
                    mat_indx[material_idx].extend(noePack('3H', *f))
        
        materials = mesh.materials
        for n, ibuf in enumerate(mat_indx.values()):
            if ibuf:
                rapi.rpgSetMaterial(materials[n].name if n < len(materials) else 'mat_{0}_{1}'.format(i, n))
                rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, len(ibuf) >> 1, noesis.RPGEO_TRIANGLE)
    else:
        ibuf = bytearray()
        for x in mesh.posFaces:
            if len(x.indices) == 3:
                ibuf.extend(struct.pack('3H', *x.indices))
            else:
                for f in triangulate_polygon(x.indices):
                    ibuf.extend(struct.pack('3H', *f))
        rapi.rpgSetMaterial('mat_default_{0}'.format(i))
        rapi.rpgCommitTriangles(bytes(ibuf), noesis.RPGEODATA_USHORT, len(ibuf) >> 1, noesis.RPGEO_TRIANGLE)

    rapi.rpgClearBufferBinds()
    return 1
        
def triangulate_polygon(vertex_indices):
    n = len(vertex_indices)
    if n < 3:
        raise ValueError("Not enough vertices for triangulation")

    triangles = [None] * (n - 2)
    v0 = vertex_indices[0]

    for i in range(n - 2):
        triangles[i] = (v0, vertex_indices[i + 1], vertex_indices[i + 2])
    
    return triangles
        
def convert_material(raw_mat):
    if raw_mat.isReference:
        return
        
    mat = NoeMaterial(raw_mat.name, '')

    for x in raw_mat.textures:
        name = x.name.decode('ascii', 'ignore')
        if not x.isNormalMap:
            mat.setTexture(name)
        else:
            mat.setNormalTexture(name)
    
    mat.setDiffuseColor(NoeVec4(raw_mat.diffuse))
    mat.setSpecularColor(NoeVec4(list(raw_mat.specular) + [raw_mat.specularExponent]))
    materials.append(mat)
    
def convert_anim(anim):
    TICKS_PER_SECOND = 4800.0
    print('name:',anim.name,'keys:', len(anim.anims))

    animBones = []
    for a in anim.anims:
        pos_count = len(a.posKeys) + len(a.trafoKeys)
        rot_count = len(a.rotKeys) + len(a.trafoKeys)
        scl_count = len(a.scaleKeys) + len(a.trafoKeys)
        
        posList = [None] * pos_count
        rotList = [None] * rot_count
        sclList = [None] * scl_count
        
        for i, (time, pos) in enumerate(a.posKeys):
            posList[i] = NoeKeyFramedValue(time / TICKS_PER_SECOND, NoeVec3(pos))
            
        for i, (time, rot) in enumerate(a.rotKeys):
            rotList[i] = NoeKeyFramedValue(time / TICKS_PER_SECOND, NoeQuat(rot))
        
        for i, (time, scl) in enumerate(a.scaleKeys):
            sclList[i] = NoeKeyFramedValue(time / TICKS_PER_SECOND, NoeVec3(scl))
        
        p_trafo_offset = len(a.posKeys)
        r_trafo_offset = len(a.rotKeys)
        s_trafo_offset = len(a.scaleKeys)
        
        for i, (time, matrix_data) in enumerate(a.trafoKeys):
            time_sec = time / TICKS_PER_SECOND
            mtrx = NoeMat44.fromBytes(noePack('16f', *matrix_data)).toMat43()
            rot, pos, scl = Mat43_Decompose(mtrx)
            
            posList[p_trafo_offset + i] = NoeKeyFramedValue(time_sec, pos)
            rotList[r_trafo_offset + i] = NoeKeyFramedValue(time_sec, rot)
            sclList[s_trafo_offset + i] = NoeKeyFramedValue(time_sec, scl)

        id = getBoneIndex(a.boneName.decode('ascii', 'ignore'))
        if id != -1:
            keyBone = NoeKeyFramedBone(id) 
            keyBone.setTranslation(posList)
            keyBone.setRotation(rotList)
            keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            
    anim = NoeKeyFramedAnim(anim.name, bones, animBones, 30)
    anims.append(anim)

def Mat43_Decompose(mat):
    rot = mat.toQuat()
    
    pos = mat[3]
    
    scale_x = mat[0].length() if mat[0].length() > 1e-6 else 1.0
    scale_y = mat[1].length() if mat[1].length() > 1e-6 else 1.0
    scale_z = mat[2].length() if mat[2].length() > 1e-6 else 1.0
    scl = NoeVec3([scale_x, scale_y, scale_z])
    
    return rot, pos, scl

def getBoneIndex(name):
    return bone_map.get(name, -1)